
public class NewClass {
    
}
